def HelloWorld() -> str:
    """Hello world function
    Takes no arguments returns a string
    """
    return("HellowWorld")